# mutagonglab.html 적용 방법 (직접 임베드)

1. 이 폴더의 customizer/ 폴더를 저장소 루트(mutagonglab.html과 같은 위치)에 업로드
   → customizer/skus/... , customizer/assets/bg.png
2. customizer-section.html 내용 전체를 복사해
   mutagonglab.html의 "무타공랩 커스터마이징" 섹션(지금 바로, 나만의 무타공 중문을... 아래)에 붙여넣기
3. 커밋 & 푸시 → GitHub Pages 반영 확인

- 스타일은 #mtg-customizer 로 스코프되어 기존 페이지 CSS와 충돌하지 않습니다.
- 구매하기 버튼은 alert 데모 상태 — contact.html 연결 예:
  $('buyBtn').onclick=function(){location.href='contact.html?brand=mutagonglab&sku='+encodeURIComponent($('sku').textContent);};
